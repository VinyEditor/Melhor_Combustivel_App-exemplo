package com.example.melhorcombustivel

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Combustivel : AppCompatActivity() {

    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)

        setContentView(R.layout.layout_home)

        val edtAlcool = findViewById<EditText>(R.id.edtAlcool)
        val edtGasolina = findViewById<EditText>(R.id.edtGasolina)
        val btnAvaliar = findViewById<Button>(R.id.btnAvaliar)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)

        btnAvaliar.setOnClickListener{
           val valor = edtGasolina.text.toString().toFloat() * 0.70
            val alcool = edtAlcool.text.toString().toFloat()
            if (alcool < valor) {
                txtResultado.text = "Alcool"
            } else if (alcool == valor.toFloat()) {
                txtResultado.text = "Tanto Faz"}
           else {
                txtResultado.text = "Gasolina"}

    }

}