package com.example.melhorcombustivel

class OutraActivity {
}